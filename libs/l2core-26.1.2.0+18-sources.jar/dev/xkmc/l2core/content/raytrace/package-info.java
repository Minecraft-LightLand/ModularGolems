@org.jspecify.annotations.NullMarked

package dev.xkmc.l2core.content.raytrace;

