@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault

package dev.xkmc.mob_weapon_api.integration.twilightforest;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;