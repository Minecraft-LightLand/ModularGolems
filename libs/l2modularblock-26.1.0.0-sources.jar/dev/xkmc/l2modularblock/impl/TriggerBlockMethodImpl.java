package dev.xkmc.l2modularblock.impl;

import dev.xkmc.l2modularblock.mult.CreateBlockStateBlockMethod;
import dev.xkmc.l2modularblock.mult.DefaultStateBlockMethod;
import dev.xkmc.l2modularblock.mult.NeighborUpdateBlockMethod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.redstone.Orientation;
import org.jetbrains.annotations.Nullable;

public class TriggerBlockMethodImpl implements NeighborUpdateBlockMethod, CreateBlockStateBlockMethod, DefaultStateBlockMethod {

	private final int delay;

	public TriggerBlockMethodImpl(int delay) {
		this.delay = delay;
	}

	@Override
	public void neighborChanged(Block self, BlockState state, Level world, BlockPos pos, Block nei_block, @Nullable Orientation orientation, boolean moving) {
		boolean flag = world.hasNeighborSignal(pos) || world.hasNeighborSignal(pos.above());
		boolean flag1 = state.getValue(BlockStateProperties.TRIGGERED);
		if (flag && !flag1) {
			world.scheduleTick(pos, self, delay);
			world.setBlock(pos, state.setValue(BlockStateProperties.TRIGGERED, Boolean.TRUE), delay);
		} else if (!flag && flag1) {
			world.setBlock(pos, state.setValue(BlockStateProperties.TRIGGERED, Boolean.FALSE), delay);
		}
	}

	@Override
	public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(BlockStateProperties.TRIGGERED);
	}

	@Override
	public BlockState getDefaultState(BlockState state) {
		return state.setValue(BlockStateProperties.TRIGGERED, false);
	}
}
