package dev.xkmc.golemdungeons.content.config;

import dev.xkmc.l2core.init.reg.ench.EnchHelper;
import dev.xkmc.l2core.serial.config.BaseConfig;
import dev.xkmc.l2serial.serialization.marker.OnInject;
import dev.xkmc.l2serial.serialization.marker.SerialClass;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import dev.xkmc.modulargolems.content.entity.common.SweepGolemEntity;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.FireworkExplosion;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ItemLike;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

@SerialClass
public class EquipmentConfig extends BaseConfig {

	@SerialField
	public final LinkedHashMap<EquipmentSlot, ArrayList<EquipmentEntry>> items = new LinkedHashMap<>();

	@SerialField
	public final LinkedHashMap<ExtraEquipmentSlot, ArrayList<EquipmentEntry>> additional = new LinkedHashMap<>();

	EquipmentSetInfo<EquipmentSlot> cache;
	EquipmentSetInfo<ExtraEquipmentSlot> extraCache;

	@OnInject
	public void onInject() {
		cache = new EquipmentSetInfo<>(EquipmentConfig::setEquipment, items);
		extraCache = new EquipmentSetInfo<>(EquipmentConfig::setExtraEquipment, additional);
	}

	public EquipmentConfig add(EquipmentSlot slot, EquipmentEntry entry) {
		items.computeIfAbsent(slot, k -> new ArrayList<>()).add(entry);
		return this;
	}

	public EquipmentConfig add(ExtraEquipmentSlot slot, EquipmentEntry entry) {
		additional.computeIfAbsent(slot, k -> new ArrayList<>()).add(entry);
		return this;
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight) {
		return add(slot, new EquipmentEntry(weight));
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight, ItemLike stack) {
		return add(slot, new EquipmentEntry(weight, stack.asItem()));
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight, ItemStackTemplate stack) {
		return add(slot, new EquipmentEntry(weight, stack));
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight, ItemLike stack, int enchantLevel) {
		return add(slot, new EquipmentEntry(weight, stack.asItem(), enchantLevel));
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight, ItemLike stack, int enchantLevel, float dropChance) {
		return add(slot, new EquipmentEntry(weight, new ItemStackTemplate(stack.asItem()), enchantLevel, dropChance));
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight, ItemStackTemplate stack, int enchantLevel) {
		return add(slot, new EquipmentEntry(weight, stack, enchantLevel));
	}

	public EquipmentConfig add(EquipmentSlot slot, int weight, ItemStackTemplate stack, int enchantLevel, float dropChance) {
		return add(slot, new EquipmentEntry(weight, stack, enchantLevel, dropChance));
	}

	public record EquipmentEntry(int weight, @Nullable ItemStackTemplate stack, int enchantLevel, float dropChance) {

		public EquipmentEntry(int weight) {
			this(weight, null, 0, 0);
		}

		public EquipmentEntry(int weight, Item stack) {
			this(weight, new ItemStackTemplate(stack));
		}

		public EquipmentEntry(int weight, ItemStackTemplate stack) {
			this(weight, stack, 0);
		}

		public EquipmentEntry(int weight, Item stack, int level) {
			this(weight, new ItemStackTemplate(stack), level);
		}

		public EquipmentEntry(int weight, ItemStackTemplate stack, int level) {
			this(weight, stack, level, 0.085f);
		}

		public ItemStack get(RegistryAccess access, RandomSource r) {
			if (stack != null && stack.is(Items.FIREWORK_ROCKET)) {
				int n = enchantLevel <= 1 ? 1 : r.nextInt(enchantLevel) + 1;
				return getRocket(r, Mth.clamp(n, 1, 7));
			}
			var ans = stack == null ? ItemStack.EMPTY : stack.create();
			if (ans.isEnchantable() && enchantLevel > 0) {
				EnchantmentHelper.enchantItem(r, ans, enchantLevel, access,
						access.get(EnchantmentTags.ON_MOB_SPAWN_EQUIPMENT));
			}
			return ans;
		}

		public static ItemStack getRocket(RandomSource r, int n) {
			ItemStack ans = new ItemStack(Items.FIREWORK_ROCKET);
			var list = new ArrayList<FireworkExplosion>();
			for (int i = 0; i < n; i++) {
				list.add(new FireworkExplosion(FireworkExplosion.Shape.BURST,
						IntList.of(DyeColor.values()[r.nextInt(16)].getFireworkColor()),
						IntList.of(), false, false));
			}
			ans.set(DataComponents.FIREWORKS, new Fireworks(3, list));

			return ans;
		}

	}

	public interface Applicator<T> {

		void set(LivingEntity e, T key, EquipmentEntry item, ItemStack stack);

	}

	public static void setEquipment(LivingEntity e, EquipmentSlot slot, EquipmentEntry item, ItemStack stack) {
		e.setItemSlot(slot, stack);
		if (e instanceof Mob mob) {
			mob.setDropChance(slot, item.dropChance());
		}
	}

	public static void setExtraEquipment(LivingEntity e, ExtraEquipmentSlot slot, EquipmentEntry item, ItemStack stack) {
		if (!(e instanceof SweepGolemEntity<?, ?> golem)) return;
		if (e.getRandom().nextFloat() > item.dropChance() && EnchHelper.getLv(stack, Enchantments.VANISHING_CURSE) <= 0)
			stack.enchant(e.registryAccess().holderOrThrow(Enchantments.VANISHING_CURSE), 1);
		slot.set(golem, stack);
	}


	public static class EquipmentSetInfo<T> {

		private final Map<T, WeightedList<EquipmentEntry>> itemTable = new LinkedHashMap<>();
		private final Applicator<T> applicator;

		private EquipmentSetInfo(Applicator<T> applicator, LinkedHashMap<T, ArrayList<EquipmentEntry>> items) {
			this.applicator = applicator;
			for (var ent : items.entrySet()) {
				var builder = WeightedList.<EquipmentEntry>builder();
				for (var e : ent.getValue())
					if (e.weight() > 0)
						builder.add(e, e.weight());
				itemTable.put(ent.getKey(), builder.build());
			}
		}

		public void apply(LivingEntity e, RandomSource r) {
			for (var slot : itemTable.entrySet()) {
				var item = slot.getValue().getRandom(r);
				if (item.isEmpty()) continue;
				var stack = item.get().get(e.registryAccess(), r);
				applicator.set(e, slot.getKey(), item.get(), stack);
			}
		}
	}


}
