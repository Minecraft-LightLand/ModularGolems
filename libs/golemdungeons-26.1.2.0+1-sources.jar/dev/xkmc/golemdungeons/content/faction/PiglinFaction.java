package dev.xkmc.golemdungeons.content.faction;

import dev.xkmc.l2serial.util.LazyFunction;
import dev.xkmc.modulargolems.content.entity.common.AbstractGolemEntity;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Unit;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BannerPatternLayers;
import net.minecraft.world.level.block.entity.BannerPatterns;

import java.util.List;

public class PiglinFaction extends DungeonFaction {

	private static final LazyFunction<Level, ItemStack> BANNER = LazyFunction.create(level -> {
		var reg = level.registryAccess().lookupOrThrow(Registries.BANNER_PATTERN);
		ItemStack stack = new ItemStack(Items.WHITE_BANNER);
		stack.set(DataComponents.BANNER_PATTERNS, new BannerPatternLayers(List.of(
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.STRIPE_SMALL), DyeColor.YELLOW),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.BRICKS), DyeColor.GRAY),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.CURLY_BORDER), DyeColor.BLACK),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.TRIANGLES_BOTTOM), DyeColor.RED),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.TRIANGLES_BOTTOM), DyeColor.ORANGE),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.TRIANGLES_TOP), DyeColor.ORANGE),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.PIGLIN), DyeColor.RED),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.GRADIENT_UP), DyeColor.ORANGE),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.GRADIENT), DyeColor.ORANGE),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.BORDER), DyeColor.BLACK),
				new BannerPatternLayers.Layer(reg.getOrThrow(BannerPatterns.PIGLIN), DyeColor.YELLOW)
		)));
		stack.set(DataComponents.TOOLTIP_DISPLAY, TooltipDisplay.DEFAULT.withHidden(DataComponents.BANNER_PATTERNS, true));
		return stack;
	});

	public PiglinFaction(Identifier id) {
		super(id);
	}

	@Override
	public ItemStack getBanner(AbstractGolemEntity<?, ?> e, int col) {
		return BANNER.get(e.level());
	}

	@Override
	public boolean isAlliedTo(Entity other) {
		if (other instanceof AbstractPiglin) return validAlly(other);
		return super.isAlliedTo(other);
	}

}
