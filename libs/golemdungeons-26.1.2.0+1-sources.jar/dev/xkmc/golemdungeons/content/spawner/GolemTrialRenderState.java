package dev.xkmc.golemdungeons.content.spawner;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class GolemTrialRenderState extends BlockEntityRenderState {

	public List<BlockPos> targets = new ArrayList<>();

	@Nullable
	public Identifier trial;


}
