package dev.xkmc.golemdungeons.content.equipments;

import com.tterrag.registrate.util.entry.ItemEntry;
import dev.xkmc.golemdungeons.init.GolemDungeons;
import dev.xkmc.golemdungeons.init.data.GDLang;
import dev.xkmc.golemdungeons.init.data.GDModelGen;
import dev.xkmc.l2damagetracker.contents.attack.OnDamageSourceModifyEvent;
import dev.xkmc.modulargolems.content.entity.metalgolem.MetalGolemEntity;
import dev.xkmc.modulargolems.content.item.equipments.MetalGolemWeaponItem;
import dev.xkmc.modulargolems.init.material.GolemWeaponType;
import dev.xkmc.modulargolems.init.material.VanillaGolemWeaponMaterial;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

import java.util.function.Consumer;

public class AncientForge extends MetalGolemWeaponItem implements GolemCustomSourceWeapon {

	public AncientForge(Properties properties, int attackDamage, double percentAttack, float range, float sweep) {
		super(properties, attackDamage, percentAttack, range, sweep, 200);
	}

	@Override
	public void onModifySource(OnDamageSourceModifyEvent event, MetalGolemEntity golem, ItemStack stack) {
		event.enable(DamageTypeTags.BYPASSES_ARMOR);
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext ctx, TooltipDisplay disp, Consumer<Component> list, TooltipFlag flag) {
		list.accept(GDLang.ANCIENT_FORGE_ATK.get());
		super.appendHoverText(stack, ctx, disp, list, flag);
	}

	public static ItemEntry<AncientForge> buildItem(String id, VanillaGolemWeaponMaterial material) {
		return GolemDungeons.REGISTRATE.item(id, p -> new AncientForge(material.modify(p.stacksTo(1)),
						2, 0, 1, 0))
				.model(() -> (ctx, pvd) ->
						GDModelGen.genWeaponModel(ctx, pvd, GolemWeaponType.SPEAR))
				.tag(ItemTags.WEAPON_ENCHANTABLE)
				.defaultLang().register();
	}

}
