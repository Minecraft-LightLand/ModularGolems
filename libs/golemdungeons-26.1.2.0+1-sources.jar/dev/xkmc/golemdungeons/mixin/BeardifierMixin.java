package dev.xkmc.golemdungeons.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import dev.xkmc.golemdungeons.content.structure.GDCustomPiece;
import net.minecraft.world.level.levelgen.Beardifier;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

@Mixin(Beardifier.class)
public class BeardifierMixin {

	@WrapOperation(method = "forStructuresInChunk", at = @At(value = "INVOKE",
			target = "Ljava/util/List;add(Ljava/lang/Object;)Z", remap = false, ordinal = 1))
	private static boolean golemdungeons$add(
			List instance, Object obj, Operation<Boolean> original, @Local(name = "piece") StructurePiece piece
	) {
		if (obj instanceof Beardifier.Rigid && piece instanceof PoolElementStructurePiece poolPiece) {
			if (poolPiece.getElement() instanceof GDCustomPiece simple) {
				return original.call(instance, new Beardifier.Rigid(
						simple.getBeardifierBox(piece),
						simple.getTerrainAdjustment(),
						simple.getGroundLevelDelta()
				));
			}
		}
		return original.call(instance, obj);
	}

}
