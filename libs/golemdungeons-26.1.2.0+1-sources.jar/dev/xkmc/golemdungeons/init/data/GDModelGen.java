package dev.xkmc.golemdungeons.init.data;

import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.generators.RegistrateBlockModelGenerator;
import com.tterrag.registrate.providers.generators.RegistrateItemModelGenerator;
import dev.xkmc.golemdungeons.content.spawner.GolemTrialBlock;
import dev.xkmc.l2modularblock.core.DelegateBlock;
import dev.xkmc.modulargolems.init.material.GolemWeaponType;
import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.blockstates.MultiVariantGenerator;
import net.minecraft.client.data.models.blockstates.PropertyDispatch;
import net.minecraft.client.data.models.model.ItemModelUtils;
import net.minecraft.client.data.models.model.ModelTemplates;
import net.minecraft.client.data.models.model.TextureMapping;
import net.minecraft.client.data.models.model.TextureSlot;
import net.minecraft.client.renderer.item.properties.select.DisplayContext;
import net.minecraft.client.resources.model.sprite.Material;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.block.Block;

public class GDModelGen {

	public static void buildTrialBlock(DataGenContext<Block, DelegateBlock> ctx, RegistrateBlockModelGenerator pvd) {
		var sel = PropertyDispatch.initial(GolemTrialBlock.STATE);
		for (var state : GolemTrialBlock.State.values()) {
			String suffix = state == GolemTrialBlock.State.IDLE ? "" : ("_" + state.getSerializedName());
			var model = pvd.createSuffixedVariant(ctx.get(), suffix, ModelTemplates.CUBE_ALL, TextureMapping::cube);
			sel.select(state, BlockModelGenerators.plainVariant(model));
		}
		pvd.blockStateOutput.accept(MultiVariantGenerator.dispatch(ctx.get()).with(sel));
	}

	public static <T extends Item> void genWeaponModel(DataGenContext<Item, T> ctx, RegistrateItemModelGenerator pvd, GolemWeaponType type) {
		var template = ModelTemplates.createItem(type.model, TextureSlot.LAYER0);
		var large = new Material(pvd.modLoc("item/equipments/" + ctx.getName()));
		var small = new Material(pvd.modLoc("item/equipments/" + ctx.getName() + "_icon"));
		var model = template.create(ctx.get(), TextureMapping.layer0(large), pvd.modelOutput);
		var icon = ModelTemplates.FLAT_ITEM.create(pvd.modLoc("item/" + ctx.getName() + "_icon"),
				TextureMapping.layer0(small), pvd.modelOutput);
		pvd.itemModelOutput.accept(ctx.get(), ItemModelUtils.select(new DisplayContext(), ItemModelUtils.plainModel(model),
				ItemModelUtils.when(ItemDisplayContext.GUI, ItemModelUtils.plainModel(icon))
		));
	}

}
