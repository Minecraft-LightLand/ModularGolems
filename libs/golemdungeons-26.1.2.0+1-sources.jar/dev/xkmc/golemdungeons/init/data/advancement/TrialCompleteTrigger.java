package dev.xkmc.golemdungeons.init.data.advancement;

import dev.xkmc.l2core.serial.advancements.BaseCriterion;
import dev.xkmc.l2core.serial.advancements.BaseCriterionInstance;
import dev.xkmc.l2serial.serialization.marker.SerialClass;
import dev.xkmc.l2serial.serialization.marker.SerialField;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

public class TrialCompleteTrigger extends BaseCriterion<TrialCompleteTrigger.Ins, TrialCompleteTrigger> {

	public static Ins ins(Identifier trial) {
		Ins ans = new Ins();
		ans.trial = trial;
		return ans;
	}

	public TrialCompleteTrigger() {
		super(Ins.class);
	}

	public void trigger(ServerPlayer player, Identifier trial) {
		this.trigger(player, e -> trial.equals(e.trial));
	}

	@SerialClass
	public static class Ins extends BaseCriterionInstance<Ins, TrialCompleteTrigger> {

		@SerialField
		private Identifier trial;

		public Ins() {
			super(GDTriggers.COMPLETE.get());
		}

	}

}
