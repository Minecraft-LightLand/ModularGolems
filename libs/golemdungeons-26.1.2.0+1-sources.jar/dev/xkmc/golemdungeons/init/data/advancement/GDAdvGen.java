package dev.xkmc.golemdungeons.init.data.advancement;

import com.tterrag.registrate.providers.RegistrateAdvancementProvider;
import dev.xkmc.golemdungeons.init.GolemDungeons;
import dev.xkmc.golemdungeons.init.data.spawn.FactoryGolemSpawn;
import dev.xkmc.golemdungeons.init.data.spawn.PiglinGolemSpawn;
import dev.xkmc.golemdungeons.init.data.spawn.SculkGolemSpawn;
import dev.xkmc.golemdungeons.init.data.structure.GDStructureGen;
import dev.xkmc.golemdungeons.init.reg.GDItems;
import dev.xkmc.golemdungeons.init.reg.GDModifiers;
import dev.xkmc.l2core.init.reg.ench.DataGenHolder;
import dev.xkmc.l2core.serial.advancements.AdvancementGenerator;
import dev.xkmc.l2core.serial.advancements.CriterionBuilder;
import net.minecraft.advancements.AdvancementType;
import net.minecraft.advancements.criterion.LocationPredicate;
import net.minecraft.advancements.criterion.PlayerTrigger;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.structure.Structure;

public class GDAdvGen {

	public static void genAdv(RegistrateAdvancementProvider pvd) {
		AdvancementGenerator gen = new AdvancementGenerator(pvd, GolemDungeons.MODID);

		var root = gen.new TabBuilder("dungeons")
				.root("visit_abandoned_factory", GDItems.EYE_OF_ANCIENT_FACTORY.get(),
						visit(pvd, GDStructureGen.ABANDONED_FACTORY.asKey()),
						"Remnant of History", "Visit Abandoned Golem Factory");
		var defeat = root.create("defeat_abandoned_factory", GDItems.ANCIENT_FORGE.get(),
				CriterionBuilder.Provider.one(TrialCompleteTrigger.ins(FactoryGolemSpawn.FACTORY_ALL).build()),
				"Mechanical Warfare", "Defeat Trial of Abandoned Factory");

		defeat.create("visit_piglin_factory", GDItems.EYE_OF_CRIMSON_FACTORY.asItem(),
						visit(pvd, GDStructureGen.PIGLIN_FACTORY.asKey()),
						"Ancient War Machine", "Visit Piglin Golem Factory")
				.create("defeat_piglin_factory", GDItems.FLAME_SWORD.get(),
						CriterionBuilder.Provider.one(TrialCompleteTrigger.ins(PiglinGolemSpawn.PIGLIN_ALL).build()),
						"Legacy of Golden Time", "Defeat Trial of Piglin Legacy")
				.create("reforge_upgrade", GDModifiers.ITEM_REFORGE.get(),
						CriterionBuilder.Provider.item(GDModifiers.ITEM_REFORGE.get()),
						"Melt and Repair", "Craft Reforge Upgrade")
				.type(AdvancementType.GOAL);

		defeat.create("visit_sculk_factory", GDItems.EYE_OF_SCULK_FACTORY.asItem(),
						visit(pvd, GDStructureGen.SCULK_FACTORY.asKey()),
						"Infested Laboratory", "Visit Sculk Infested Golem Factory")
				.create("defeat_sculk_factory", GDItems.SCULK_SCYTHE.get(),
						CriterionBuilder.Provider.one(TrialCompleteTrigger.ins(SculkGolemSpawn.SCULK_ALL).build()),
						"The Hidden Calamity", "Defeat Trial of Sculk Infestation")
				.create("resistance_upgrade", GDModifiers.ITEM_RESISTANCE.get(),
						CriterionBuilder.Provider.item(GDModifiers.ITEM_RESISTANCE.get()),
						"Rob the Golem", "Use Slicing Axe to obtain Resistance Upgrade")
				.type(AdvancementType.CHALLENGE);

		//TODO compat
		/*if (ModList.get().isLoaded(CataDispatch.MODID)) {
			CataclysmCompatData.genAdv(pvd, defeat);
		}
		if (ModList.get().isLoaded(TFDispatch.MODID)) {
			TwilightCompatData.genAdv(pvd, defeat);
		}

		 */

		root.finish();

	}

	private static CriterionBuilder visit(RegistrateAdvancementProvider pvd, ResourceKey<Structure> key) {
		return CriterionBuilder.Provider.one(PlayerTrigger.TriggerInstance.located(LocationPredicate.Builder.inStructure(new DataGenHolder<>(key, null))));
	}

}
