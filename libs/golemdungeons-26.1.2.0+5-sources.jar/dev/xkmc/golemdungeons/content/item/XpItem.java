package dev.xkmc.golemdungeons.content.item;

import dev.xkmc.golemdungeons.init.data.GDLang;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;

import java.util.function.Consumer;

public class XpItem extends Item {

	public final int amount;

	public XpItem(Properties properties, int amount) {
		super(properties);
		this.amount = amount;
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!level.isClientSide()) {
			player.giveExperiencePoints(amount);
			player.getCooldowns().addCooldown(player.getItemInHand(hand), 4);
			if (!player.isCreative()) {
				player.getItemInHand(hand).shrink(1);
			}
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public void appendHoverText(ItemStack itemStack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag tooltipFlag) {
		builder.accept(GDLang.GIVE_EXP.get(amount));
	}

}
