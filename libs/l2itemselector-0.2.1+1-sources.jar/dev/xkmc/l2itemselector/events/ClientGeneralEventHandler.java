package dev.xkmc.l2itemselector.events;

import com.mojang.blaze3d.platform.InputConstants;
import dev.xkmc.l2itemselector.init.L2ItemSelector;
import dev.xkmc.l2itemselector.init.data.L2Keys;
import dev.xkmc.l2itemselector.select.SelectionRegistry;
import dev.xkmc.l2itemselector.wheel.InputHandler;
import dev.xkmc.l2itemselector.wheel.WheelHandler;
import dev.xkmc.l2library.init.L2LibraryConfig;
import dev.xkmc.l2library.util.Proxy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = L2ItemSelector.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientGeneralEventHandler {

	/**
	 * 轮盘是 overlay 而不是 Screen，按 Esc 会打开原版暂停菜单。轮盘打开时拦下暂停界面，
	 * 改为关闭轮盘（对物品选择器和傀儡轮盘等所有 WheelHandler 轮盘统一生效）。
	 */
	@SubscribeEvent
	public static void screenOpening(ScreenEvent.Opening event) {
		if (event.getNewScreen() instanceof PauseScreen && WheelHandler.wheel != null) {
			event.setCanceled(true);
			WheelHandler.disableWheel(Minecraft.getInstance().player);
		}
	}

	@SubscribeEvent
	public static void clientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.START) return;
		if (Minecraft.getInstance().level == null) {
			WheelHandler.handleTick(null);
			return;
		}
		Player player = Minecraft.getInstance().player;
		WheelHandler.handleTick(player);
	}

	@SubscribeEvent
	public static void inputEvent(GenericKeyEvent event) {
		LocalPlayer player = Proxy.getClientPlayer();
		if (player == null) return;
		var sel = InputHandler.getHandler(player);
		if (sel.isEmpty()) return;
		for (L2Keys k : L2Keys.values()) {
			if (event.test(k.map.getKey()) &&
					event.getAction() == InputConstants.PRESS) {
				sel.get().handleClientKey(k, player);
				return;
			}
		}
	}

	@SubscribeEvent
	public static void mouseEvent(InputEvent.MouseButton.Pre event) {
		if (WheelHandler.handleClick(event)) return;
		MinecraftForge.EVENT_BUS.post(new GenericKeyEvent(e -> e.getType() == InputConstants.Type.MOUSE && e.getValue() == event.getButton(), event.getAction()));
	}

	@SubscribeEvent
	public static void keyEvent(InputEvent.Key event) {
		MinecraftForge.EVENT_BUS.post(new GenericKeyEvent(e -> e.getType() != InputConstants.Type.MOUSE && e.getValue() == event.getKey(), event.getAction()));
		LocalPlayer player = Proxy.getClientPlayer();
		if (player == null) return;
		var sel = SelectionRegistry.getClientActiveListener(player);
		if (sel.isEmpty()) return;
		for (int i = 0; i < 9; i++) {
			if (sel.get().handleClientNumericKey(i, Minecraft.getInstance().options.keyHotbarSlots[i]::consumeClick)) {
				return;
			}
		}

	}

	private static double scroll;

	@SubscribeEvent
	public static void scrollEvent(InputEvent.MouseScrollingEvent event) {
		double d0 = event.getScrollDelta();
		scroll += d0;
		int i = (int) scroll;
		scroll -= i;
		LocalPlayer player = Proxy.getClientPlayer();
		if (player == null) return;
		var sel = InputHandler.getHandler(player);
		if (sel.isEmpty()) return;
		if (!sel.get().scrollBypassShift() &&
				L2LibraryConfig.CLIENT.selectionScrollRequireShift.get() &&
				!sel.get().isHoldKeyDown(player)) return;
		if (sel.get().handleClientScroll(i, d0, player)) {
			event.setCanceled(true);
		}
	}
}
